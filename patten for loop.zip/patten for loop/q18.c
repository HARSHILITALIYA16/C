#include<stdio.h>
void main()
{
    int i,j,a=5;
    for(i=1;i<=5;i++)
    {
        for(j=5;j>0;j--)
        {
            printf("%d ",j);
        }
        printf("\n");
        
    }
}