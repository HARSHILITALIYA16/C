#include<stdio.h>
void main()
{
    int i,j,s;
    for(i=1;i<=5;i++)
    {
        for(j=i;j<=4;j++)
        {
            printf(" ");
        }
        for(s=1;s<=(i*2)-1;s++)
        {
            printf("%d",s);
        }
        printf("\n");
        
    }
    for(i=4;i>=1;i--)
    {
        for(j=4;j>=i;j--)
        {
            printf(" ");
        }
        for(s=1;s<=(i*2)-1;s++)
        {
            printf("%d",s);
        }
        printf("\n");
    }
}